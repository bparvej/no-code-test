# Simple Ash Calculator

A lightweight native Android calculator with a simple ash-gray interface and a small anchored adaptive banner using Google's official **test** AdMob IDs.

## What's included
- Basic arithmetic: +, −, ×, ÷, decimals, percentage, sign change, clear and backspace.
- Expression evaluation with operator precedence and parentheses support in the calculation engine.
- Ash-gray UI.
- Google test banner ad; no production ad IDs are included.
- GitHub Actions workflow to build the APK on a cloud Linux runner, not on your Mac.

## Get the APK without building on your Mac
1. Create a free GitHub account if needed and create a new repository, e.g. `simple-ash-calculator`.
2. Upload the contents of this folder to the repository (not the enclosing folder itself), then commit to the `main` branch.
3. Open the repository's **Actions** tab and choose **Build Android APK**.
4. Run the workflow using **Run workflow** if it hasn't run automatically.
5. When it finishes successfully, open the completed run and download the `simple-calculator-debug-apk` artifact. Extract the ZIP to get `app-debug.apk`.

The build runs on GitHub's cloud runner; your Mac only needs a browser.

## Before production / Google Play
- The current APK build is a debug APK for testing, not a Play Store release.
- Replace the test AdMob App ID in `app/src/main/AndroidManifest.xml` and test banner unit ID in `MainActivity.java` with IDs from your own AdMob account before production.
- Confirm the app's privacy policy, Data safety declarations, ads declaration, target SDK requirements, and other Play Console requirements.
- For Play publishing, generate a signed Android App Bundle (AAB) and securely manage your signing key. Do not commit signing keys or credentials to GitHub.
- Never click your own live ads. Test ads are for development only.

## Package
`com.sobuj.simpleashcalculator`

## Local build (optional)
With JDK 17, Android SDK platform 35, and Gradle 8.9 installed, run `gradle assembleDebug`. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.
