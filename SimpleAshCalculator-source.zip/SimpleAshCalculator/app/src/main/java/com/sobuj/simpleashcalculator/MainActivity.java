package com.sobuj.simpleashcalculator;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(242,242,242);
    private static final int BUTTON = Color.WHITE;
    private static final int OPERATOR = Color.rgb(220,220,220);
    private static final int TEXT = Color.rgb(32,32,32);
    private TextView expressionView, resultView;
    private String expression = "";
    private boolean justEvaluated = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        MobileAds.initialize(this, status -> {});

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(4));
        root.setBackgroundColor(BG);

        TextView title = new TextView(this);
        title.setText("Calculator"); title.setTextColor(TEXT); title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        title.setPadding(dp(4), dp(4), 0, dp(8));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL); display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setPadding(dp(12), dp(16), dp(12), dp(16)); display.setBackgroundColor(Color.rgb(231,231,231));
        expressionView = new TextView(this); expressionView.setTextColor(Color.rgb(100,100,100)); expressionView.setTextSize(20); expressionView.setGravity(Gravity.END);
        resultView = new TextView(this); resultView.setText("0"); resultView.setTextColor(TEXT); resultView.setTextSize(42); resultView.setSingleLine(true); resultView.setGravity(Gravity.END);
        display.addView(expressionView, new LinearLayout.LayoutParams(-1, -2));
        display.addView(resultView, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams displayParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        displayParams.bottomMargin = dp(12); root.addView(display, displayParams);

        String[][] keys = {
            {"AC", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"±", "0", ".", "="}
        };
        GridLayout grid = new GridLayout(this); grid.setColumnCount(4); grid.setRowCount(5);
        for (String[] row : keys) for (String key : row) {
            Button b = new Button(this); b.setText(key); b.setTextSize(23); b.setAllCaps(false); b.setTextColor(TEXT);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(isOperator(key) ? OPERATOR : BUTTON));
            b.setStateListAnimator(null); b.setPadding(0, 0, 0, 0);
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(); p.width = 0; p.height = 0;
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); p.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            p.setMargins(dp(4), dp(4), dp(4), dp(4)); grid.addView(b, p);
            b.setOnClickListener(v -> onKey(key));
        }
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 2.2f));

        // Small adaptive banner. This is Google's official TEST ad unit; replace before production.
        LinearLayout adSlot = new LinearLayout(this); adSlot.setGravity(Gravity.CENTER); adSlot.setPadding(0, dp(4), 0, 0);
        root.addView(adSlot, new LinearLayout.LayoutParams(-1, -2));
        AdView adView = new AdView(this);
        adView.setAdUnitId("ca-app-pub-3940256099942544/9214589741");
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density > 0 ? (int)(getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density) - 32 : 320));
        adSlot.addView(adView);
        adView.loadAd(new AdRequest.Builder().build());
        setContentView(root);
    }

    private boolean isOperator(String s) { return s.equals("AC") || s.equals("⌫") || s.equals("%") || s.equals("÷") || s.equals("×") || s.equals("−") || s.equals("+") || s.equals("=") || s.equals("±"); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void onKey(String key) {
        try {
            if (key.equals("AC")) { expression = ""; expressionView.setText(""); resultView.setText("0"); justEvaluated = false; return; }
            if (key.equals("⌫")) { if (justEvaluated) { expression = ""; justEvaluated = false; } else if (!expression.isEmpty()) expression = expression.substring(0, expression.length()-1); updateDisplay(); return; }
            if (key.equals("=")) {
                if (expression.trim().isEmpty()) return;
                double result = new Parser(expression).parse();
                if (!Double.isFinite(result)) throw new IllegalArgumentException();
                expressionView.setText(expression.replace("*", "×").replace("/", "÷"));
                resultView.setText(format(result)); expression = format(result); justEvaluated = true; return;
            }
            if (key.equals("±")) {
                if (justEvaluated) { expression = "-" + expression; justEvaluated = false; }
                else if (expression.startsWith("-")) expression = expression.substring(1); else expression = "-" + expression;
            } else if (key.equals("%")) {
                if (!expression.isEmpty()) { double val = new Parser(expression).parse(); expression = format(val / 100.0); justEvaluated = false; }
            } else {
                if (justEvaluated && !isOperator(key)) expression = "";
                justEvaluated = false;
                switch (key) { case "÷": expression += "/"; break; case "×": expression += "*"; break; case "−": expression += "-"; break; default: expression += key; }
            }
            updateDisplay();
        } catch (Exception e) { Toast.makeText(this, "Please check the calculation", Toast.LENGTH_SHORT).show(); }
    }
    private void updateDisplay() { expressionView.setText(expression.replace("*", "×").replace("/", "÷")); resultView.setText(expression.isEmpty() ? "0" : expression.replace("*", "×").replace("/", "÷")); }
    private String format(double n) {
        if (Math.abs(n) < 1e-10) n = 0;
        DecimalFormat f = new DecimalFormat("0.##########"); f.setGroupingUsed(false); return f.format(n);
    }

    private static class Parser {
        private final String s; private int pos = -1, ch;
        Parser(String s) { this.s = s; }
        double parse() { next(); double x = expression(); if (pos < s.length()) throw new IllegalArgumentException(); return x; }
        void next() { ch = (++pos < s.length()) ? s.charAt(pos) : -1; }
        boolean eat(int c) { while (ch == ' ') next(); if (ch == c) { next(); return true; } return false; }
        double expression() { double x = term(); for (;;) { if (eat('+')) x += term(); else if (eat('-')) x -= term(); else return x; } }
        double term() { double x = factor(); for (;;) { if (eat('*')) x *= factor(); else if (eat('/')) { double d = factor(); if (d == 0) throw new IllegalArgumentException(); x /= d; } else return x; } }
        double factor() {
            if (eat('+')) return factor(); if (eat('-')) return -factor();
            double x; int start = pos;
            if (eat('(')) { x = expression(); if (!eat(')')) throw new IllegalArgumentException(); }
            else if ((ch >= '0' && ch <= '9') || ch == '.') { while ((ch >= '0' && ch <= '9') || ch == '.') next(); x = Double.parseDouble(s.substring(start, pos)); }
            else throw new IllegalArgumentException();
            return x;
        }
    }
}
